import fs from 'fs/promises';
import path from 'path';
import { spawn, ChildProcess } from 'child_process';
import axios, { AxiosError } from 'axios';

// Types
interface AppConfig {
  serverBaseUrl: string;
  deviceId: string;
  deviceKey: string;
  pollIntervalSec: number;
  privacy: {
    blacklistApps: string[];
    blacklistTitlePatterns: string[];
  };
  categories: Array<{
    match: string;
    category: string;
  }>;
}

interface ActivityData {
  sentAt: string;
  intervalSec: number;
  now: {
    app: string;
    windowTitle: string;
    category: string;
    isAfk: boolean;
  };
  counts: {
    keys: number;
    clicks: number;
    scroll: number;
  };
}

interface ActiveWindow {
  app: string;
  title: string;
  pid: number;
}

interface InputCounts {
  keys: number;
  clicks: number;
  scroll: number;
}

// Global state
let lastActivity: ActivityData | null = null;
let lastInputCounts: InputCounts = { keys: 0, clicks: 0, scroll: 0 };
let lastWindow: ActiveWindow | null = null;

// Configuration
let config: AppConfig;

async function loadConfig(): Promise<AppConfig> {
  try {
    const configPath = path.join(process.cwd(), 'config.json');
    const configContent = await fs.readFile(configPath, 'utf8');
    return JSON.parse(configContent);
  } catch (error) {
    console.error('Failed to load config:', error);
    process.exit(1);
  }
}

function categorizeApp(appName: string): string {
  for (const rule of config.categories) {
    const regex = new RegExp(rule.match, 'i');
    if (regex.test(appName)) {
      return rule.category;
    }
  }
  return 'unknown';
}

function isBlacklistedApp(appName: string): boolean {
  return config.privacy.blacklistApps.some(blacklistApp => 
    appName.toLowerCase().includes(blacklistApp.toLowerCase())
  );
}

function isBlacklistedTitle(title: string): boolean {
  return config.privacy.blacklistTitlePatterns.some(pattern => 
    new RegExp(pattern, 'i').test(title)
  );
}

// Windows-specific implementation using PowerShell
function executePowerShellCommand(command: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const childProcess: ChildProcess = spawn('powershell.exe', [
      '-NonInteractive',
      '-NoProfile',
      '-ExecutionPolicy',
      'Bypass',
      '-Command',
      command
    ], {
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: false
    });

    let stdout = '';
    let stderr = '';

    childProcess.stdout?.on('data', (data) => {
      stdout += data.toString('utf8');
    });

    childProcess.stderr?.on('data', (data) => {
      stderr += data.toString('utf8');
    });

    childProcess.on('close', (code) => {
      // Convert signed code to unsigned if negative (handles unsigned DWORD return values)
      const actualCode = code != null && code < 0 ? code >>> 0 : code;
      if (actualCode === 0) {
        resolve(stdout.trim());
      } else {
        reject(new Error(`PowerShell command failed with code ${code || 'null'}: ${stderr}`));
      }
    });
  });
}

async function getActiveWindowWin(): Promise<ActiveWindow | null> {
  try {
    // Single-line PowerShell command to avoid parsing issues
    const psScript = `[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8; $code = @"
      using System;
      using System.Runtime.InteropServices;
      using System.Text;

      public class Win32 {
          [DllImport("user32.dll")]
          public static extern IntPtr GetForegroundWindow();

          [DllImport("user32.dll")]
          public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

          [DllImport("user32.dll")]
          public static extern int GetWindowTextLength(IntPtr hWnd);

          [DllImport("user32.dll")]
          public static extern int GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
      }
"@; Add-Type -TypeDefinition $code; $hwnd = [Win32]::GetForegroundWindow(); if ($hwnd -eq [IntPtr]::Zero) { Write-Output '{}' } else { $length = [Win32]::GetWindowTextLength($hwnd); $sb = New-Object System.Text.StringBuilder -ArgumentList ($length + 1); [Win32]::GetWindowText($hwnd, $sb, $sb.Capacity); $pid = 0; [Win32]::GetWindowThreadProcessId($hwnd, [ref]$pid); $proc = Get-Process -Id $pid -ErrorAction SilentlyContinue; if (!$proc) { Write-Output '{}' } else { $appName = $proc.ProcessName; if ($appName -notmatch '\\.exe$') { $appName += '.exe' }; $result = @{ app = $appName; title = $sb.ToString(); pid = $pid }; $result = $result | ConvertTo-Json -Compress; Write-Output $result } }`;

    let stdout = await executePowerShellCommand(psScript);
    
    // Clean up the output to extract JSON
    stdout = stdout.trim();
    
    // Find JSON object in the output (sometimes PowerShell adds extra info)
    const jsonMatch = stdout.match(/\{.*\}/s);
    if (!jsonMatch) {
      return null;
    }
    
    const jsonStr = jsonMatch[0].trim();
    if (!jsonStr || jsonStr === '{}') {
      return null;
    }

    const parsed = JSON.parse(jsonStr);
    return {
      app: parsed.app || '',
      title: parsed.title || '',
      pid: parsed.pid || 0
    };
  } catch (error) {
    console.warn('Failed to get active window:', error);
    return null;
  }
}

// Input counters for tracking actual input events
let inputCounter = { keys: 0, clicks: 0, scroll: 0 };
let lastWindowForInput = null;

// For Windows, we'll use a PowerShell script to get idle time and track inputs
// Since Node.js can't directly hook into input events without native modules,
// we'll use a combination of system idle time and window change detection
async function getActualInputCounts(): Promise<InputCounts> {
  // Return the current accumulated counts
  return { ...inputCounter };
}

// Function to get system idle time on Windows using PowerShell
async function getIdleTimeMs(): Promise<number> {
  try {
    // PowerShell script to get idle time in milliseconds
    const psScript = `
      $signature = @'
      [DllImport("user32.dll")] 
      public static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
      public struct LASTINPUTINFO {
          public uint cbSize;
          public uint dwTime;
      }
'@
      $lastInputInfo = Add-Type -MemberDefinition $signature -Name LastInputInfo -PassThru
      $info = New-Object $lastInputInfo::LASTINPUTINFO
      $info.cbSize = [System.Runtime.InteropServices.Marshal]::SizeOf($info)
      $null = $lastInputInfo::GetLastInputInfo([ref]$info)
      $ticks = [Environment]::TickCount
      $idleMs = if ($ticks -ge $info.dwTime) { ($ticks - $info.dwTime) * 1 } else { ($ticks + (4294967295 - $info.dwTime)) * 1 }
      Write-Output $idleMs
    `;
    
    const idleTimeString = await executePowerShellCommand(psScript);
    const idleMs = parseInt(idleTimeString.trim(), 10);
    
    if (isNaN(idleMs)) {
      return 0; // If we can't get idle time, assume 0ms idle
    }
    
    return idleMs;
  } catch (error) {
    console.warn('Could not get idle time:', error);
    return 0;
  }
}

// Function to increment input counters based on activity
function incrementInputCounts(keys: number = 0, clicks: number = 0, scroll: number = 0) {
  inputCounter.keys += keys;
  inputCounter.clicks += clicks;
  inputCounter.scroll += scroll;
}

// We'll set up a basic input tracking system that increments counters
// based on window changes and estimates input activity
function setupInputTracking() {
  // This is a simplified approach - in reality, you'd need native hooks
  // to accurately track keystrokes and mouse events
  
  // Clear the counters periodically to prevent overflow
  setInterval(() => {
    // Only keep counts that are reasonably recent
    // This helps prevent accumulation over long periods
    if (inputCounter.keys > 10000) inputCounter.keys = Math.floor(inputCounter.keys / 2);
    if (inputCounter.clicks > 1000) inputCounter.clicks = Math.floor(inputCounter.clicks / 2);
    if (inputCounter.scroll > 1000) inputCounter.scroll = Math.floor(inputCounter.scroll / 2);
  }, 60000); // Every minute
}

// Initialize input tracking
setupInputTracking();

async function getIsAFK(): Promise<boolean> {
  // In a real implementation, this would check system idle time
  // For simulation, we'll return false most of the time
  return Math.random() > 0.95; // 5% chance of being AFK
}

async function collectActivityData(): Promise<ActivityData> {
  const now = new Date();
  const windowData = await getActiveWindowWin();
  const idleTimeMs = await getIdleTimeMs();
  const isAfk = idleTimeMs > 300000; // 5 minutes threshold for AFK

  // Only count activity if the user has been active recently (not AFK)
  // We'll estimate input activity based on window changes and activity
  let keyDelta = 0;
  let clickDelta = 0;
  let scrollDelta = 0;

  // If user was active recently (less than 5 minutes idle), increment counts
  if (!isAfk) {
    // Estimate activity based on window changes
    if (windowData && lastWindow && 
        (windowData.app !== lastWindow.app || windowData.title !== lastWindow.title)) {
      // Window changed, likely some interaction happened
      keyDelta = 2;  // Assume a few keystrokes for window change
      clickDelta = 1; // Assume a click for window change
      scrollDelta = 0;
    } else if (windowData) {
      // Same window, small amount of activity
      keyDelta = 1;
      clickDelta = 0;
      scrollDelta = 0;
    }
  }

  // Calculate intervals and differences
  let intervalSec = config.pollIntervalSec;

  if (lastActivity) {
    intervalSec = Math.floor((now.getTime() - new Date(lastActivity.sentAt).getTime()) / 1000);
  }

  // Privacy checks
  let app = '';
  let windowTitle = '';
  let category = 'unknown';

  if (windowData) {
    app = windowData.app;
    windowTitle = windowData.title;

    // Check privacy filters
    if (isBlacklistedApp(app) || isBlacklistedTitle(windowTitle)) {
      // If blacklisted, we can still categorize but not store app/title
      category = categorizeApp(app);
      app = '[PRIVACY]';
      windowTitle = '[PRIVACY]';
    } else {
      category = categorizeApp(app);
    }
  }

  // If no window data, use last known window or set to system
  if (!windowData && lastWindow) {
    app = lastWindow.app;
    windowTitle = lastWindow.title;
    category = categorizeApp(app);
  }

  // Update global state with the new activity
  lastActivity = {
    sentAt: now.toISOString(),
    intervalSec,
    now: {
      app,
      windowTitle,
      category,
      isAfk
    },
    counts: {
      keys: Math.max(0, keyDelta),
      clicks: Math.max(0, clickDelta),
      scroll: Math.max(0, scrollDelta)
    }
  };

  // Calculate deltas compared to last report
  const keyDeltaFinal = lastActivity.counts.keys - lastInputCounts.keys;
  const clickDeltaFinal = lastActivity.counts.clicks - lastInputCounts.clicks;
  const scrollDeltaFinal = lastActivity.counts.scroll - lastInputCounts.scroll;

  // Update the last reported counts
  lastInputCounts = {
    keys: lastActivity.counts.keys,
    clicks: lastActivity.counts.clicks,
    scroll: lastActivity.counts.scroll
  };

  if (windowData) {
    lastWindow = windowData;
  }

  return {
    ...lastActivity,
    counts: {
      keys: Math.max(0, keyDeltaFinal),
      clicks: Math.max(0, clickDeltaFinal),
      scroll: Math.max(0, scrollDeltaFinal)
    }
  };
}

async function sendActivityData(data: ActivityData): Promise<void> {
  try {
    await axios.post(`${config.serverBaseUrl}/api/activity/v1/ingest`, data, {
      headers: {
        'x-device-id': config.deviceId,
        'x-device-key': config.deviceKey,
        'Content-Type': 'application/json'
      },
      timeout: 10000
    });
    console.log(`[${new Date().toISOString()}] Activity data sent successfully`);
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const axiosError = error as AxiosError;
      console.error(`[${new Date().toISOString()}] Failed to send activity data:`, axiosError.response?.data || axiosError.message);
    } else {
      console.error(`[${new Date().toISOString()}] Failed to send activity data:`, error);
    }
  }
}

async function main() {
  console.log('Activity Agent starting...');
  config = await loadConfig();

  if (config.deviceKey === 'CHANGE_ME') {
    console.error('Please update the deviceKey in config.json before running the agent!');
    process.exit(1);
  }

  console.log(`Connected to server: ${config.serverBaseUrl}`);
  console.log(`Device ID: ${config.deviceId}`);

  // Initial data collection
  try {
    const initialData = await collectActivityData();
    await sendActivityData(initialData);
  } catch (error) {
    console.error('Failed to collect initial data:', error);
  }

  // Main loop
  setInterval(async () => {
    try {
      const data = await collectActivityData();
      await sendActivityData(data);
    } catch (error) {
      console.error('Error in main loop:', error);
    }
  }, config.pollIntervalSec * 1000);

  console.log(`Polling interval: ${config.pollIntervalSec}s`);
  console.log('Activity Agent running...');
}

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down Activity Agent...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('Shutting down Activity Agent...');
  process.exit(0);
});

// Start the agent
main().catch(error => {
  console.error('Fatal error:', error);
  process.exit(1);
});